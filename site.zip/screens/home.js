
import {DAY,HOUR} from '../domain.js';
import {money,number,days,modelName,escape as esc} from '../format.js';
import {estimateRange} from '../shared/range-estimate.js';
import {icon,button,modelImage,shortDate,sectionTitle,tripRow,routeShape,pageTitle,mapHTML} from '../ui/components.js';

export function homeScreen(state,routes){
 const expired=state.lease.endsAt<=Date.now(),returning=state.status==='return_requested',early=state.lease.endsAt-Date.now()>=48*HOUR;
 const remaining=Math.max(0,Math.ceil((state.lease.endsAt-Date.now())/DAY));
 const route=routes.find(r=>r.id===(state.ride?.routeId||state.trips[0]?.routeId))||routes[0];
 const range=estimateRange({modelId:state.selection.model,batteryCount:1});
 const km=Math.floor(range.lowerKm*state.bike.charge/100);
 const status=returning?'Ожидает возврата':expired?'Срок истёк':state.bike.connection?'На связи':'Нет связи';
 const lead=`
 <section class="bike-stage" aria-label="Твой байк">
  <div class="bike-identity"><div><p class="overline">ТВОЙ ЭЛЕКТРОБАЙК</p><h1>${modelName(state.selection.model)}</h1></div><span class="connection ${!state.bike.connection?'warning':''}">${icon('wifi')}${status}</span></div>
  <span class="model-shadow" aria-hidden="true">${state.selection.model==='u2'?'U2':'V8'}</span>
  ${modelImage(state.selection.model)}
  <span class="instance-number">${state.lease.vehicleId}</span>
 </section>
 <button class="energy-strip" data-action="battery-info" aria-label="Заряд аккумуляторов и оценка запаса хода">
  <span class="energy-cell"><span class="energy-label">${icon('battery')}Основной</span><strong class="${state.bike.charge<20?'charge-low':''}" data-live-charge>${Math.round(state.bike.charge)}<small>%</small></strong><span class="energy-track"><i data-live-meter style="width:${state.bike.charge}%"></i></span></span>
  <span class="energy-cell"><span class="energy-label">Запасной</span><strong>${Math.round(state.bike.spareCharge)}<small>%</small></strong><span class="energy-track"><i style="width:${state.bike.spareCharge}%"></i></span></span>
  <span class="energy-cell range-cell"><span class="energy-label">Запас хода</span><strong data-live-range>~${km}<small> км</small></strong><span class="energy-note">Оценка ${icon('arrow')}</span></span>
 </button>`;
 let lease;
 if(returning)lease=`<section class="lease-card"><span class="lease-kicker">ЗАЯВКА НА ВОЗВРАТ</span><h2>Ждём приёмку</h2><p>Байк остаётся за тобой до передачи команде.</p>${button('Статус возврата','return-status')}</section>`;
 else if(expired)lease=`<section class="lease-card expired"><span class="lease-kicker">АРЕНДА ЗАКОНЧИЛАСЬ</span><h2>Согласуем продление</h2><p>Срок закончился ${shortDate(state.lease.endsAt)}.</p>${button('Связаться с командой','support')}</section>`;
 else lease=`<section class="lease-card" aria-label="Текущая аренда">
  <div class="lease-top"><div><span class="lease-kicker">${state.selection.format==='subscription'?'ПОДПИСКА':'ТВОЯ АРЕНДА'}</span><h2>До ${shortDate(state.lease.endsAt)}</h2></div><span class="days-left"><strong>${remaining}</strong><span>${days(remaining)} осталось</span></span></div>
  <button class="gift-line" data-action="bonus-info">${icon('gift')}<span>${early?`Продли до ${shortDate(state.lease.endsAt-48*HOUR)} — получи +1 день`:'Продление доступно без подарочного дня'}</span><span class="chevron">${icon('arrow')}</span></button>
  ${button('Продлить аренду','renew','primary','id="main-renew"')}
 </section>`;
 const notice=state.bike.charge<20?`<button class="notice warning" data-action="battery-info">${icon('battery')}<span><b>Пора сменить аккумулятор</b><small>Запасной заряжен на ${Math.round(state.bike.spareCharge)}%</small></span>${icon('arrow')}</button>`:!state.bike.connection?`<button class="notice warning" data-action="connection-info">${icon('wifi')}<span><b>Байк не на связи</b><small>Последние данные: ${shortDate(state.bike.lastSeenAt,true)}</small></span>${icon('arrow')}</button>`:'';
 const location=`${sectionTitle('Где мой байк')}<button class="location-preview" data-action="location"><span class="location-art">${routeShape(route)}<span class="location-pin">${icon('pin')}</span></span><span class="location-caption"><span><b>${esc(state.ride?'Байк в пути':route?.endName||'Санкт-Петербург')}</b><small>${state.bike.connection?'Последнее местоположение':'Данные могут быть устаревшими'}</small></span><span class="round-arrow">${icon('arrow')}</span></span></button>`;
 return lead+lease+notice+`<div class="below-fold">${state.ride?`<button class="live-trip-banner" data-action="trips"><span class="live-pulse"></span><span><b>Байк в пути</b><small>Маршрут записывается</small></span>${icon('arrow')}</button>`:''}${location}
 ${state.trips[0]?sectionTitle('Последняя поездка','trips')+tripRow(state.trips[0],routes.find(r=>r.id===state.trips[0].routeId)):''}
 ${sectionTitle('Моя аренда','payments','История')}<div class="menu-group"><button class="rental-detail" data-action="documents"><span class="menu-icon">${icon('documents')}</span><span class="grow"><b>Договор и документы</b><small>${state.documents.length} документа · ${state.lease.vehicleId}</small></span>${icon('arrow')}</button>${state.renewals.slice(0,1).map(r=>{const doc=state.documents.find(d=>d.paymentId===r.paymentId);return `<button class="rental-detail" data-action="document" data-id="${doc?.id||''}"><span class="menu-icon">${icon('gift')}</span><span class="grow"><b>Последнее продление</b><small>${r.paidDays} ${days(r.paidDays)}${r.bonusDays?' + 1 в подарок':''} · ${money(r.amount)}</small></span>${icon('arrow')}</button>`}).join('')}</div></div>`;
}
export function locationScreen(state,routes){
 const route=routes.find(r=>r.id===(state.ride?.routeId||state.trips[0]?.routeId))||routes[0];
 return pageTitle('Местоположение','home')+`<div class="location-full">${mapHTML(route,Boolean(state.ride))}</div><div class="location-info"><span class="label">${state.bike.connection?'ПОСЛЕДНЕЕ ПОЛОЖЕНИЕ':'НЕТ СВЯЗИ'}</span><h2>${esc(state.ride?'Байк в пути':route?.endName||'Санкт-Петербург')}</h2><p>${shortDate(state.bike.lastSeenAt,true)} МСК</p><div class="stat-pair"><div><strong>${number(state.bike.odometerKm)}<small> км</small></strong><span>Общий пробег</span></div><div><strong>${state.lease.vehicleId}</strong><span>Только твой байк</span></div></div><p class="fine">${state.bike.connection?'Положение и телеметрия демонстрационные.':'Положение и заряд могут быть устаревшими. Поддержка поможет проверить связь.'}</p>${!state.bike.connection?button('Связаться с поддержкой','support','secondary'):''}</div>`;
}

