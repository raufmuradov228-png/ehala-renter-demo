import {checkoutScreen,lifecycleScreen} from './screens/checkout.js';
import {tripsScreen,tripScreen} from './screens/trips.js';
import {profileScreen,documentsScreen,paymentsScreen} from './screens/profile.js';
import {presenterSheet} from './ui/presenter.js';
import {icon,button} from './ui/components.js';
import {normalizeRoute} from './ui/navigation.js';
import {homeScreen,locationScreen} from './screens/home.js';
import {renewalSheet,renewalSuccess} from './ui/renewal.js';

import * as D from './domain.js';
import {money,date,modelName,days,number,offerLabel,escape as esc} from './format.js';
import {estimateRange} from './shared/range-estimate.js';
import {documentSections} from './documents.js';
const KEY='ehala.renter.demo.v1',uid=()=>crypto.randomUUID();
let persistence=true,storageWarning='';
function read(){try{const raw=localStorage.getItem(KEY);if(raw){const s=JSON.parse(raw);if(D.validState(s))return s;storageWarning='Сохранённое демо не удалось прочитать. Открыт новый показ.'}}catch{persistence=false;storageWarning='Сохранение недоступно. Демо работает до закрытия страницы.'}return null}
const restored=read();let state=restored||D.seedState('active');
function save(s){state=s;try{localStorage.setItem(KEY,JSON.stringify(s))}catch{persistence=false}}
save(state);
let routes=[],routeError=false,modal=null,quote=null,paymentId=null,busy=false,tab='rent',step=state.signedAt?3:1,map=null,mapGeneration=0,mapMarker=null,installPrompt=null,offlineReady=false,toastTimer,swStarted=false;
const app=document.querySelector('#app'),dialog=document.querySelector('#sheet');
const params=new URLSearchParams(location.search);
let incoming=params.has('model')&&['u2','v8'].includes(params.get('model'))?{model:params.get('model'),format:['rental','subscription'].includes(params.get('format'))?params.get('format'):'rental',days:Math.min(365,Math.max(1,Number(params.get('days'))||7)),periods:Math.min(12,Math.max(1,Number(params.get('periods'))||1)),firstCustomer:params.get('firstCustomer')==='true'}:null;
if(incoming&&(!restored||(state.status==='draft'&&!state.signedAt))){const q=D.quoteInitial(incoming);if(q.ok){save(D.newRental(incoming));incoming=null;history.replaceState(null,'',location.pathname+location.hash)}}
step=state.signedAt?3:1;
const hasBike=()=>['active','return_requested'].includes(state.status);
const expired=()=>hasBike()&&state.lease.endsAt<=Date.now();
const active=()=>state.status==='active'&&!expired();
function statusLabel(){return expired()?'Срок закончился':({draft:'Оформление',awaiting_pickup:'Ожидает выдачи',active:'Байк у тебя',return_requested:'Возврат согласуется',completed:'Аренда завершена'}[state.status])}
function toast(text){const el=document.querySelector('#toast');el.textContent=text;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),5500)}
function go(next){history.pushState(null,'',`#/${next}`);render();window.scrollTo(0,0)}
async function mutate(fn){const work=()=>{if(persistence){const latest=read();if(latest)state=latest}const result=fn(state);if(result.ok)save(result.state);return result};return navigator.locks?.request?navigator.locks.request('ehala-demo-state',work):work()}
async function setSelection(selection,q,rentalId){return mutate(s=>s.id===rentalId&&s.status==='draft'&&!s.signedAt?{ok:true,state:{...s,selection,initialQuote:q,revision:s.revision+1}}:{ok:false,message:'Оформление изменилось в другой вкладке. Открой актуальную аренду.'})}
const routeBy=id=>routes.find(r=>r.id===id);
let checkoutUI={};try{const saved=JSON.parse(localStorage.getItem('ehala.checkout.ui')||'null');if(saved?.rentalId===state.id)checkoutUI=saved}catch{}
step=checkoutUI.step||(state.signedAt?3:1);
function saveCheckout(){checkoutUI={...checkoutUI,rentalId:state.id,step};try{localStorage.setItem('ehala.checkout.ui',JSON.stringify(checkoutUI))}catch{}}
function render(){
 mapGeneration++;if(map){map.remove();map=null;mapMarker=null}
 const route=normalizeRoute(location.hash);tab=route.tab;
 if(location.hash!==route.hash)history.replaceState(null,'',location.pathname+location.search+route.hash);
 const screens={home:()=>state.status==='draft'?checkoutScreen(state,step,checkoutUI):['awaiting_pickup','completed'].includes(state.status)?lifecycleScreen(state):homeScreen(state,routes),trips:()=>tripsScreen(state,routes),trip:()=>tripScreen(state,routes,route.id),profile:()=>profileScreen(state,{offlineReady,persistence}),documents:()=>documentsScreen(state),payments:()=>paymentsScreen(state),location:()=>locationScreen(state,routes),'return-status':()=>lifecycleScreen(state)};
 app.innerHTML=screens[route.screen]();
 document.querySelectorAll('.bottom-nav a').forEach(a=>{const selected=a.getAttribute('href')===`#/${tab}`;a.classList.toggle('active',selected);a.setAttribute('aria-current',selected?'page':'false')});
 document.querySelector('#connectivity').hidden=navigator.onLine;
 document.title=({home:'Мой байк',trips:'Поездки',profile:'Профиль'}[tab])+' · Ехала';
 if(document.querySelector('#live-map'))mountMap();if(state.ride)updateRideDOM();
}
async function mountMap(){
 const root=document.querySelector('.map-wrap');if(!root||!navigator.onLine)return;
 const route=routeBy(root.dataset.route),generation=mapGeneration;if(!route)return;
 try{
 const lib=await import('./vendor/maplibre-gl.mjs');if(generation!==mapGeneration)return;
 lib.setWorkerUrl(new URL('./vendor/maplibre-gl-worker.mjs',import.meta.url).href);
 map=new lib.Map({container:root.querySelector('#live-map'),style:'https://tiles.openfreemap.org/styles/bright',center:route.coordinates[0],zoom:12,attributionControl:true,interactive:true});
 map.addControl(new lib.NavigationControl({showCompass:false}),'top-right');
 const currentMap=map;
 currentMap.on('load',()=>{
  if(generation!==mapGeneration||map!==currentMap)return;
  currentMap.addSource('trip',{type:'geojson',data:{type:'Feature',properties:{},geometry:{type:'LineString',coordinates:route.coordinates}}});
  currentMap.addLayer({id:'route-shadow',type:'line',source:'trip',paint:{'line-color':'#28391c','line-width':8}});
  currentMap.addLayer({id:'route',type:'line',source:'trip',paint:{'line-color':'#c5fa36','line-width':4}});
  const bounds=route.coordinates.reduce((b,c)=>b.extend(c),new lib.LngLatBounds(route.coordinates[0],route.coordinates[0]));
  currentMap.fitBounds(bounds,{padding:42,duration:0});
  mapMarker=new lib.Marker({color:'#263b16'}).setLngLat(routePosition(route,root.dataset.live==='true'?(state.ride?.progress??1):1)).addTo(currentMap);
  root.classList.add('map-ready');document.querySelector('#map-mode').textContent='Собственный байк · демоположение';
 });
 currentMap.on('error',()=>{if(generation===mapGeneration&&!currentMap.isStyleLoaded())root.classList.remove('map-ready')});
 }catch{}
}
function routePosition(route,progress){return route.coordinates[Math.min(route.coordinates.length-1,Math.round((route.coordinates.length-1)*progress))]}
function clearPending(){try{localStorage.removeItem('ehala.renew.pending')}catch{}}
function persistPending(){try{if(quote?.ok)localStorage.setItem('ehala.renew.pending',JSON.stringify({rentalId:state.id,id:paymentId,quote}))}catch{}}
function closeModal(){dialog.close();dialog.innerHTML='';modal=null;quote=null;paymentId=null;clearPending()}
function showModal(title,html,type='generic'){modal=type;dialog.innerHTML=`<div class="sheet-heading"><h2>${title}</h2><button class="icon-button" data-action="close" aria-label="Закрыть">${icon('close')}</button></div><div class="sheet-body">${html}</div>`;if(!dialog.open)dialog.showModal()}
function openRenew(message=''){
 if(!active()){toast('Для продления нужна действующая аренда.');return}
 paymentId=paymentId||uid();const previous=quote;
 quote=D.quoteRenewal({model:state.selection.model,format:state.selection.format,endsAt:state.lease.endsAt,days:previous?.paidDays||7,periods:previous?.periods||1});
 if(!quote.ok){toast(quote.message);return}
 persistPending();showModal('Продлить аренду',renewalSheet(state,quote,message),'renew');
}
function updateRenew(){
 const input=document.querySelector('#renew-duration');if(!input)return;
 const submit=dialog.querySelector('button[type="submit"]');
 if(!input.checkValidity()){quote=null;clearPending();submit.disabled=true;return}
 const n=Number(input.value);quote=D.quoteRenewal({model:state.selection.model,format:state.selection.format,endsAt:state.lease.endsAt,days:n,periods:n});
 if(!quote.ok){dialog.querySelector('.form-error').textContent=quote.message;submit.disabled=true;clearPending();return}
 persistPending();const template=document.createElement('template');template.innerHTML=renewalSheet(state,quote);
 for(const selector of ['.renew-gift','#renew-quote','.offer-status'])dialog.querySelector(selector).replaceWith(template.content.querySelector(selector));
 submit.innerHTML=template.content.querySelector('button[type="submit"]').innerHTML;submit.disabled=false;dialog.querySelector('.form-error').textContent='';
 dialog.querySelectorAll('[data-action="duration"]').forEach(el=>{el.classList.toggle('selected',Number(el.dataset.id)===n);el.setAttribute('aria-pressed',String(Number(el.dataset.id)===n))});
 const custom=!(state.selection.format==='subscription'?[1,2,3]:[7,14,30]).includes(n);dialog.querySelector('[data-action="other-duration"]').classList.toggle('selected',custom);
}
function showDocument(id){const doc=state.documents.find(d=>d.id===id);if(!doc)return;showModal(doc.title,`<span class="tag">Демо · ${doc.id}</span><div class="document-preview">${documentSections(doc).map(s=>`<section><h3>${esc(s.title)}</h3>${s.lines.map(line=>`<p>${esc(line)}</p>`).join('')}</section>`).join('')}</div>${button('Скачать PDF','download','primary',`data-id="${doc.id}"`)}`)}
async function download(id){const doc=state.documents.find(d=>d.id===id);if(!doc)return;toast('Готовим PDF…');try{const {createPDF}=await import('./vendor/pdf.mjs');const bytes=await createPDF(doc);const blob=new Blob([bytes],{type:'application/pdf'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`ehala-${doc.type}-${doc.id}.pdf`;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('PDF готов. Он появится в загрузках браузера.')}catch{toast('PDF пока недоступен. Открой документ для просмотра и попробуй скачать при подключении.')}}


function scenario(id,model=state.selection.model){
 const known=['new','pickup','active','early','late','subscription','trip','low','offline','expired'];if(!known.includes(id)||!['u2','v8'].includes(model))throw Error('Неизвестный сценарий');
 save(D.seedState(id,model));step=1;checkoutUI={};saveCheckout();closeModal();
 if(id==='early'||id==='late'||id==='subscription'){go('home');openRenew()}
 else if(id==='trip'){const r=routes[0];if(r)save(D.startRide(state,r.id,uid()).state);go('trips')}
 else go('home');
 toast('Сценарий готов');
}
function support(){showModal('На связи с Ехала',`<p>Для вопросов об аренде, байке и продлении.</p><form id="support-form"><label class="field">Тема<select name="topic"><option value="service">Байк и обслуживание</option><option value="renewal">Продление аренды</option><option value="other">Другой вопрос</option></select></label><label class="field">Сообщение<textarea name="text" minlength="5" maxlength="500" rows="4" placeholder="Что случилось?" required></textarea></label><p class="form-error" role="alert"></p><button class="button primary">Сохранить демообращение ${icon('arrow')}</button><p class="fine">Это демонстрация: сообщение не отправляется сотрудникам.</p></form>${state.tickets.length?`<h3>Обращения в демо</h3>${state.tickets.map(t=>`<div class="inset"><b>${t.id} · ${t.status}</b><p>${esc(t.text)}</p></div>`).join('')}`:''}`)}
async function action(name,el){
 switch(name){
 case 'home':case 'rent':case 'bike':case 'trips':case 'documents':case 'profile':case 'payments':case 'location':case 'return-status':closeModal();go(name);break;
 case 'presenter':showModal('Демо',presenterSheet(state),'presenter');break;
 case 'renew':quote=null;paymentId=uid();openRenew();break;
 case 'close':closeModal();break;
 case 'duration':document.querySelector('#renew-duration').value=el.dataset.id;document.querySelector('#custom-duration').hidden=true;updateRenew();break;
 case 'other-duration':document.querySelector('#custom-duration').hidden=false;document.querySelector('#renew-duration').focus();break;
 case 'bonus-info':showModal('Ещё день с байком',`<p>Оплати от 7 дней не позднее чем за 48 часов до окончания — добавим один день в подарок.</p><p>Оставшееся время сохраняется. Для подписки правило действует от одного периода в 30 дней.</p><p class="fine">Точное время: ${date(state.lease.endsAt-48*D.HOUR)} МСК. Первоначальные +2 дня повторно не начисляются.</p>`);break;
 case 'battery-info':showModal('Энергия на весь день',`<h3>Основной — ${Math.round(state.bike.charge)}%</h3><p>Запасной — ${Math.round(state.bike.spareCharge)}%. ${state.bike.charge<20?'Остановись в безопасном месте и замени аккумулятор.':'Заменить аккумулятор можно на остановке.'}</p><p class="fine">Запас хода — оценка для 80 кг, 25 км/ч, без груза. Телеметрия демонстрационная.</p>`);break;
 case 'selection':if(!state.signedAt){step=1;saveCheckout();render()}break;
 case 'contract-step':step=2;saveCheckout();render();break;
 case 'payment-step':step=3;saveCheckout();render();break;
 case 'contract-details':showModal('Условия демонстрации',`<p>Байк закрепляется за тобой после выдачи. Срок начинается в момент выдачи; состав комплекта указан в акте.</p><p>Продление добавляет оплаченный срок к прежней дате окончания. Раннее продление от 7 дней за 48 часов или раньше даёт один подарочный день.</p><p>Заявка на возврат не завершает аренду. Завершение подтверждает команда после приёмки.</p><p class="fine">Вымышленные данные. Демокод, договор и оплата не создают юридических обязательств.</p>`);break;
 case 'connection-info':showModal('Байк не на связи',`<p>Последнее обновление: ${date(state.bike.lastSeenAt)} МСК. Заряд и положение могут быть устаревшими.</p><p>Если связь не восстановилась, обратись в поддержку.</p>${button('Связаться с поддержкой','support')}`);break;
 case 'initial-pay':{paymentId='initial-'+state.id;const r=await mutate(s=>D.initialPayment(s,paymentId));if(r.ok){paymentId=null;render();toast('Демооплата прошла. Ждём выдачу.')}else toast(r.message);break}
 case 'handover':{const r=await mutate(s=>D.handover(s,uid()));if(r.ok){closeModal();go('home');toast('Байк выдан. Срок аренды начался.')}else toast(r.message);break}
 case 'accept-return':{const r=await mutate(s=>D.acceptReturn(s,uid()));if(r.ok){closeModal();go('home');toast('Возврат подтверждён сотрудником.')}else toast(r.message);break}
 case 'return':if(state.status==='return_requested'){closeModal();go('return-status')}else showModal('Вернуть байк',`<p>Команда согласует время и место приёмки. До передачи байка аренда остаётся активной.</p><div class="renew-gift"><span>Текущий срок</span><b>${date(state.lease.endsAt)} МСК</b></div><p class="fine">Демонстрация: реальное обращение не отправляется.</p>${button('Оставить заявку','request-return')}`);break;
 case 'request-return':{const r=await mutate(s=>D.requestReturn(s));if(r.ok){closeModal();go('return-status');toast('Заявка на возврат сохранена.')}else toast(r.message);break}

 case 'new':scenario('new');break;
 case 'reset':scenario('active');break;
 case 'support':support();break;
 case 'notifications':showModal('Уведомления',state.notifications.map(n=>`<article class="notification"><span class="tile-icon">${icon('bell')}</span><div><b>${esc(n.title)}</b><p>${esc(n.text)}</p><small>${date(n.at)} МСК</small></div></article>`).join('')||'<p>События аренды появятся здесь.</p>');break;
 case 'install':
  if(installPrompt){await installPrompt.prompt();installPrompt=null}
  else showModal('Всегда под рукой',`<div class="install-brand"><img src="./favicon.svg" alt="">ехала.</div><h3>На iPhone</h3><p>Открой ссылку в Safari, нажми «Поделиться» → «На экран Домой» → «Добавить».</p><h3>На Android</h3><p>В меню Chrome выбери «Установить приложение» или «Добавить на главный экран».</p><div class="inset"><b>${offlineReady?'Готово к работе без сети':'Первый запуск — с интернетом'}</b><p>Открой приложение по ссылке. Вход в аккаунт не нужен. После первой загрузки экраны, история и схема маршрута доступны без сети на этом устройстве.</p></div>`);break;
 case 'document':showDocument(el.dataset.id);break;
 case 'download':await download(el.dataset.id);break;
 case 'trip':closeModal();go('trips/'+encodeURIComponent(el.dataset.id));break;
 case 'start-ride':{if(!routes[0]){toast('Маршрут ещё загружается');break}const r=await mutate(s=>D.startRide(s,routes[0].id,uid()));if(r.ok){closeModal();go('trips')}else toast(r.message);break}
 case 'pause-ride':await mutate(s=>s.ride?{ok:true,state:{...s,revision:s.revision+1,ride:{...s.ride,paused:!s.ride.paused}}}:{ok:true,state:s});render();showModal('Демо',presenterSheet(state),'presenter');break;
 case 'reload-routes':await loadRoutes();render();break;
 case 'incoming':{if(incoming&&D.quoteInitial(incoming).ok){save(D.newRental(incoming));incoming=null;step=1;checkoutUI={};saveCheckout();closeModal();go('rent');history.replaceState(null,'',location.pathname+location.hash)}break}
 }
}
document.addEventListener('click',async e=>{const el=e.target.closest('[data-action]');if(!el||busy)return;busy=true;try{await action(el.dataset.action,el)}catch(error){console.error(error);toast('Не удалось выполнить действие. Попробуй ещё раз.')}finally{busy=false}});
document.addEventListener('submit',async e=>{
 if(!e.target.matches('#selection-form,#contract-form,#renew-form,#support-form,#scenario-form'))return;
 e.preventDefault();if(busy)return;const form=e.target,data=new FormData(form);busy=true;const btn=form.querySelector('button[type="submit"],button:not([type])');if(btn)btn.disabled=true;
 try{
 if(form.id==='selection-form'){
  const selection={model:data.get('model'),format:data.get('format'),days:Number(data.get('days')||7),periods:Number(data.get('periods')||1),firstCustomer:data.has('firstCustomer')},q=D.quoteInitial(selection);
  if(!q.ok)throw Error(q.message);
  if(state.status!=='draft'||state.signedAt)throw Error('Аренда уже оформлена. Открой её актуальное состояние.');
  const result=await setSelection(selection,q,state.id);if(!result.ok)throw Error(result.message);step=2;saveCheckout();render();window.scrollTo(0,0);
 }
 if(form.id==='contract-form'){const r=await mutate(s=>D.signContract(s,{code:String(data.get('code')),accepted:data.has('accepted')}));if(!r.ok)throw Error(r.message);step=3;saveCheckout();render();window.scrollTo(0,0)}
 if(form.id==='renew-form'){
  if(!quote?.ok)throw Error('Проверь срок продления.');
  const rentalId=state.id;const request={id:paymentId,expectedEndsAt:quote.oldEndsAt,displayedBonusDays:quote.bonusDays,displayedEndsAt:quote.endsAt,days:quote.paidDays,periods:quote.periods||1};
  const r=await mutate(s=>s.id===rentalId?D.renew(s,request,Date.now()):{ok:false,code:'REPLACED',message:'Демоаренда заменена. Закрой расчёт и открой новую аренду.'});
  if(!r.ok){if(['QUOTE_CHANGED','STALE'].includes(r.code)){openRenew(r.message);return}throw Error(r.message)}
  const completedQuote=quote,completedId=paymentId;closeModal();render();showModal('Готово',renewalSuccess(state,completedQuote,completedId),'success');
 }
 if(form.id==='scenario-form'){scenario(data.get('scenario'),data.get('model'))}
 if(form.id==='support-form'){const r=await mutate(s=>D.addTicket(s,{topic:data.get('topic'),text:data.get('text')}));if(!r.ok)throw Error(r.message);support();toast('Демообращение сохранено на устройстве.')}
 }catch(error){const field=form.querySelector('.form-error');if(field)field.textContent=error.message;else toast(error.message)}finally{busy=false;if(btn)btn.disabled=false}
});
function rememberContract(form){const data=new FormData(form);checkoutUI={...checkoutUI,accepted:data.has('accepted'),code:String(data.get('code')||'')};saveCheckout()}
document.addEventListener('input',e=>{if(e.target.closest('#contract-form'))rememberContract(e.target.closest('form'));if(e.target.id==='renew-duration')updateRenew()});
document.addEventListener('change',async e=>{
 if(e.target.closest('#selection-form')&&state.status==='draft'&&!state.signedAt){
  const data=new FormData(document.querySelector('#selection-form')),selection={model:data.get('model'),format:data.get('format'),days:Number(data.get('days')||state.selection.days||7),periods:Number(data.get('periods')||state.selection.periods||1),firstCustomer:data.has('firstCustomer')||(state.selection.format==='subscription'&&state.selection.firstCustomer)};
  const q=D.quoteInitial(selection),form=document.querySelector('#selection-form');
  if(q.ok){const formatChanged=selection.format!==state.selection.format;if(JSON.stringify(selection)!==JSON.stringify(state.selection))checkoutUI.accepted=false;const result=await setSelection(selection,q,state.id);if(!result.ok){render();toast(result.message);return}saveCheckout();
   if(formatChanged)render();else{form.querySelectorAll('.model-option').forEach(el=>el.classList.toggle('selected',el.querySelector('input').value===selection.model));form.querySelector('.checkout-total').innerHTML=`<span>${q.useDays} ${days(q.useDays)} с байком</span><strong>${money(q.amount)}</strong>`;form.querySelector('.form-error').textContent='';}
  }else form.querySelector('.form-error').textContent=q.message;
 }
 if(e.target.id==='renew-duration')updateRenew();
});
dialog.addEventListener('cancel',e=>{e.preventDefault();closeModal()});
dialog.addEventListener('click',e=>{if(e.target===dialog){const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)closeModal()}});
window.addEventListener('hashchange',()=>{closeModal();render();window.scrollTo(0,0)});
window.addEventListener('storage',e=>{if(e.key===KEY){const next=read();if(next){const replaced=next.id!==state.id;state=next;if(replaced){checkoutUI={};step=state.signedAt?3:1;saveCheckout();closeModal();toast('В другой вкладке открыт новый демосценарий.')}render();if(modal==='renew')openRenew('Аренда обновлена в другой вкладке. Проверь расчёт.')}}});
window.addEventListener('online',render);window.addEventListener('offline',render);
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e});
async function loadRoutes(){try{const r=await fetch('./assets/trips.json');if(!r.ok)throw Error();routes=await r.json();routeError=false}catch{routeError=true}}
function updateRideDOM(){const ride=state.ride,r=ride&&routeBy(ride.routeId);if(!r)return;const p=document.querySelector('#ride-progress');if(p)p.value=ride.progress;const dist=document.querySelector('#ride-distance');if(dist)dist.textContent=number(r.distanceMeters/1000*ride.progress)+' км';const liveCharge=document.querySelector('[data-live-charge]');if(liveCharge)liveCharge.innerHTML=Math.round(state.bike.charge)+'<small>%</small>';const energyMeter=document.querySelector('[data-live-meter]');if(energyMeter)energyMeter.style.width=state.bike.charge+'%';const energyRange=document.querySelector('[data-live-range]');if(energyRange)energyRange.innerHTML='~'+Math.floor(estimateRange({modelId:state.selection.model,batteryCount:1}).lowerKm*state.bike.charge/100)+'<small> км</small>';const charge=document.querySelector('#ride-charge');if(charge)charge.textContent=Math.round(state.bike.charge)+'%';if(mapMarker&&document.querySelector('.map-wrap[data-live="true"]'))mapMarker.setLngLat(routePosition(r,ride.progress));const marker=document.querySelector('#fallback-marker');if(marker){const c=Math.cos(r.coordinates.reduce((a,p)=>a+p[1],0)/r.coordinates.length*Math.PI/180),pts=r.coordinates.map(p=>[p[0]*c,-p[1]]),xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),lx=Math.min(...xs),hx=Math.max(...xs),ly=Math.min(...ys),hy=Math.max(...ys),scale=Math.min(520/(hx-lx||1),232/(hy-ly||1)),p=pts[Math.round((pts.length-1)*ride.progress)];marker.setAttribute('cx',320+(p[0]-(lx+hx)/2)*scale);marker.setAttribute('cy',218+(p[1]-(ly+hy)/2)*scale)}}
let lastTick=performance.now(),ticking=false;
setInterval(async()=>{
 const now=performance.now(),elapsed=Math.min(1000,now-lastTick);lastTick=now;
 if(ticking||busy||document.hidden||!state.ride||state.ride.paused||!state.bike.connection)return;
 const route=routeBy(state.ride.routeId);if(!route)return;
 ticking=true;try{const r=await mutate(s=>s.ride&&!s.ride.paused?D.advanceRide(s,s.ride.progress+elapsed/1000*50/route.durationSeconds,route):{ok:true,state:s});
 if(r.ok){if(!state.ride){render();toast('Поездка завершена и добавлена в историю.')}else updateRideDOM()}else{save({...state,ride:null});render();toast(r.message)}}finally{ticking=false}
},400);
setInterval(()=>{if(modal==='renew'&&quote?.ok){const fresh=D.quoteRenewal({model:state.selection.model,format:state.selection.format,endsAt:state.lease.endsAt,days:quote.paidDays,periods:quote.periods||1});if(!fresh.ok||fresh.bonusDays!==quote.bonusDays){const notice=dialog.querySelector('.form-error');if(notice)notice.textContent='Время изменилось. Перед оплатой проверим актуальные условия.'}}},1000);
function registerTools(){
 const context=document.modelContext;if(!context?.registerTool)return;
 const lifecycle=new AbortController();window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
 const tools=[
 {name:'read_rental_demo',description:'Read the fictitious rental status, assigned bike, exact expiry and recent renewals.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:false},execute:()=>({status:state.status,model:state.selection.model,lease:state.lease,bike:state.bike,renewals:state.renewals,demonstration:true})},
 {name:'navigate_renter_section',description:'Navigate to an existing renter section without changing the rental.',inputSchema:{type:'object',properties:{section:{enum:['home','rent','bike','trips','documents','profile']}},required:['section'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:({section})=>{if(!['home','rent','bike','trips','documents','profile'].includes(section))throw Error('Invalid section');go(section);return{section}}},
 {name:'stage_demo_renewal',description:'Open and calculate a demo renewal. Does not pay or extend; confirmation stays in the visible form.',inputSchema:{type:'object',properties:{paidDays:{type:'integer',minimum:1,maximum:365},periods:{type:'integer',minimum:1,maximum:12}},additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:({paidDays=7,periods=1})=>{if(!Number.isInteger(paidDays)||paidDays<1||paidDays>365||!Number.isInteger(periods)||periods<1||periods>12||!active())throw Error('Invalid renewal');paymentId=uid();quote={paidDays,periods};openRenew();return{staged:true,quote}}}
 ];
 for(const tool of tools)try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{})}catch{}
}
render();
await loadRoutes();if(state.status!=='draft')render();registerTools();
try{const pending=JSON.parse(localStorage.getItem('ehala.renew.pending')||'null');if(!incoming&&pending?.rentalId===state.id&&pending.quote?.ok){paymentId=pending.id;quote=pending.quote;if(state.operations[paymentId]){showModal('Готово',renewalSuccess(state,quote,paymentId),'success');clearPending()}else if(active())openRenew('Расчёт восстановлен. Проверь сумму и новую дату.');else clearPending()}}catch{clearPending()}
if(storageWarning)toast(storageWarning);
if(incoming)showModal('Байк выбран на сайте',`<p>${modelName(incoming.model)} · ${incoming.format==='subscription'?incoming.periods*30:incoming.days} оплаченных дней.</p><p>На устройстве уже есть демоаренда. Новый показ заменит её историю только на этом устройстве.</p>${button('Начать новое оформление','incoming')}${button('Оставить текущую аренду','close','secondary')}`);
if('serviceWorker'in navigator)window.addEventListener('load',setupOffline,{once:true});
if(document.readyState==='complete')setupOffline();
async function setupOffline(){if(swStarted||!('serviceWorker'in navigator))return;swStarted=true;try{const reg=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});await navigator.serviceWorker.ready;navigator.serviceWorker.addEventListener('message',e=>{if(e.data?.type==='OFFLINE_READY'){offlineReady=true;if(tab==='profile')render()}});reg.active?.postMessage({type:'STATUS'});}catch{offlineReady=false}}
