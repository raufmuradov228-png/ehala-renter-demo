import {catalog} from './shared/catalog.js';
import {calculateQuote} from './shared/calculator.js';
export {catalog};
export const DAY=86400000,HOUR=3600000,STATE_VERSION=1;
export const renewalPolicy=Object.freeze({minimumPaidDays:7,advanceHours:48,bonusDays:1,formats:['rental','subscription']});
export const clone=value=>JSON.parse(JSON.stringify(value));
const time=value=>typeof value==='number'&&Number.isFinite(value)&&Number.isSafeInteger(value)&&Math.abs(value)<8e15;
const fail=(code,message,extra={})=>({ok:false,code,message,...extra});
const uid=()=>globalThis.crypto?.randomUUID?.()||String(Date.now())+Math.random().toString(36).slice(2);
export function quoteInitial({model='u2',format='rental',days=7,periods=1,firstCustomer=true}={}){
 if(!['rental','subscription'].includes(format))return fail('FORMAT','Этот формат не входит в демонстрацию.');
 const q=calculateQuote({bike:model,format,days,subscriptionPeriods:periods,firstCustomer});
 const amount=q.total??q.exampleTotal;
 if(!Number.isSafeInteger(amount)||amount<0)return fail('INPUT',q.message||'Проверь срок аренды.');
 return{ok:true,model,format,paidDays:format==='subscription'?periods*30:days,periods:format==='subscription'?periods:null,bonusDays:q.bonusDays||0,useDays:q.useDays,amount,offerStatus:q.status,catalogVersion:q.catalogVersion,firstCustomer:format==='rental'&&firstCustomer};
}
export function newRental(selection={},now=Date.now()){
 const q=quoteInitial(selection);if(!q.ok)throw Error(q.message);
 return{version:STATE_VERSION,id:uid(),revision:0,createdAt:now,status:'draft',selection:{model:q.model,format:q.format,days:q.paidDays,periods:q.periods||1,firstCustomer:q.firstCustomer},initialQuote:q,signedAt:null,lease:{startsAt:null,endsAt:null,vehicleId:null},customer:{name:'Максим Ковалёв',shortName:'Максим',phone:'+7 000 000-00-00'},bike:{charge:84,spareCharge:100,odometerKm:1286,connection:true,lastSeenAt:now},payments:[],documents:[],renewals:[],operations:{},trips:[],ride:null,tickets:[],notifications:[],scenario:'new'};
}
function commit(s){s.revision++;return{ok:true,state:s};}
function done(state,id){return typeof id==='string'&&Object.hasOwn(state.operations,id);}
function record(state,operation,type,data,now){state.operations[operation]={type,at:now,...data};}
function documentRecord(state,type,title,now,details={}){
 const doc={id:'DOC-'+String(state.documents.length+1).padStart(3,'0'),type,title,createdAt:now,model:state.selection.model,vehicleId:state.lease.vehicleId,customer:state.customer.name,...details};state.documents.unshift(doc);return doc;
}
export function signContract(state,{code,accepted},now=Date.now()){
 if(state.signedAt)return{ok:true,state,duplicate:true};
 if(state.status!=='draft')return fail('STATE','Договор уже оформлен.');
 if(!accepted)return fail('CONSENT','Подтверди ознакомление с демодоговором.');
 if(code!=='123456')return fail('CODE','Для демонстрации введи код 123456.');
 const s=clone(state);s.signedAt=now;documentRecord(s,'contract','Договор аренды',now,{...s.initialQuote,signatureAt:now,startsAt:null,endsAt:null});return commit(s);
}
export function initialPayment(state,id,now=Date.now()){
 if(done(state,id))return{ok:true,state,duplicate:true};
 if(!id||state.status!=='draft'||!state.signedAt)return fail('STATE','Сначала подтверди демодоговор.');
 const s=clone(state),q=s.initialQuote,p={id:'PAY-001',type:'initial',createdAt:now,amount:q.amount,paidDays:q.paidDays,bonusDays:q.bonusDays};
 s.payments.push(p);s.status='awaiting_pickup';record(s,id,'initial_payment',{paymentId:p.id},now);s.notifications.unshift({id:uid(),title:'Оформление завершено',text:'Ждём тебя на согласованной выдаче. Начало срока — при получении байка.',at:now});return commit(s);
}
export function handover(state,id,now=Date.now()){
 if(done(state,id))return{ok:true,state,duplicate:true};
 if(state.status!=='awaiting_pickup')return fail('STATE','Подтвердить выдачу можно после оформления.');
 const s=clone(state);s.status='active';s.lease={startsAt:now,endsAt:now+s.initialQuote.useDays*DAY,vehicleId:s.selection.model==='u2'?'EH-U2-024':'EH-V8-018'};
 documentRecord(s,'handover','Акт выдачи',now,{...s.initialQuote,startsAt:now,endsAt:s.lease.endsAt,signatureAt:s.signedAt});
 record(s,id,'handover',{},now);s.notifications.unshift({id:uid(),title:'Байк у тебя',text:'Два аккумулятора, зарядка, замок и держатель телефона — комплект выдан.',at:now});return commit(s);
}
export function quoteRenewal({model,format='rental',endsAt,now=Date.now(),days=7,periods=1}={}){
 if(!time(endsAt)||!time(now))return fail('TIME','Некорректная дата аренды.');
 if(now>=endsAt)return fail('EXPIRED','Срок закончился. Согласуй продление с командой.');
 const q=quoteInitial({model,format,days,periods,firstCustomer:false});if(!q.ok)return q;
 const bonusDays=q.paidDays>=7&&endsAt-now>=48*HOUR?1:0;
 const newEndsAt=endsAt+(q.paidDays+bonusDays)*DAY;if(!time(newEndsAt))return fail('TIME','Срок слишком большой.');
 return{...q,bonusDays,useDays:q.paidDays+bonusDays,oldEndsAt:endsAt,endsAt:newEndsAt,bonusDeadline:endsAt-48*HOUR};
}
export function renew(state,request,now=Date.now()){
 const {id,expectedEndsAt,displayedBonusDays,displayedEndsAt,days=7,periods=1}=request;
 if(done(state,id))return{ok:true,state,duplicate:true};
 if(!id||state.status!=='active')return fail('STATE','Продление доступно для действующей аренды.');
 if(expectedEndsAt!==state.lease.endsAt)return fail('STALE','Аренда уже изменилась. Проверь обновлённый расчёт.');
 const q=quoteRenewal({model:state.selection.model,format:state.selection.format,endsAt:state.lease.endsAt,now,days,periods});if(!q.ok)return q;
 if(displayedBonusDays!==q.bonusDays||displayedEndsAt!==q.endsAt)return fail('QUOTE_CHANGED','Условия обновились. Проверь новую дату и подтверди ещё раз.',{quote:q});
 const s=clone(state),p={id:'PAY-'+String(s.payments.length+1).padStart(3,'0'),type:'renewal',createdAt:now,amount:q.amount,paidDays:q.paidDays,bonusDays:q.bonusDays};
 s.payments.push(p);s.lease.endsAt=q.endsAt;s.renewals.unshift({...q,id,paymentId:p.id,createdAt:now});
 documentRecord(s,'renewal','Подтверждение продления',now,{...q,startsAt:q.oldEndsAt,paymentId:p.id});
 record(s,id,'renewal',{paymentId:p.id},now);s.notifications.unshift({id:uid(),title:q.bonusDays?'Подарочный день твой':'Аренда продлена',text:q.bonusDays?'К оплаченному сроку добавлен один день.':'Новый срок добавлен к текущему.',at:now});return commit(s);
}
export function requestReturn(state,now=Date.now()){
 if(state.status==='return_requested')return{ok:true,state,duplicate:true};
 if(state.status!=='active')return fail('STATE','Возврат доступен для выданного байка.');
 const s=clone(state);s.status='return_requested';s.returnRequestedAt=now;s.ride=null;s.notifications.unshift({id:uid(),title:'Заявка на возврат',text:'Команда согласует время приёмки. Аренда завершится после передачи байка.',at:now});return commit(s);
}
export function acceptReturn(state,id,now=Date.now()){
 if(done(state,id))return{ok:true,state,duplicate:true};
 if(state.status!=='return_requested')return fail('STATE','Сначала нужна заявка на возврат.');
 const s=clone(state);s.status='completed';s.lease.returnedAt=now;documentRecord(s,'return','Акт возврата',now,{startsAt:s.lease.startsAt,endsAt:s.lease.endsAt,returnedAt:now});record(s,id,'return',{},now);return commit(s);
}
export function startRide(state,routeId,id,now=Date.now()){
 if(!id||!routeId)return fail('INPUT','Не указан маршрут поездки.');
 if(state.trips.some(t=>t.id===id))return{ok:true,state,duplicate:true};
 if(state.status!=='active'||state.lease.endsAt<=now)return fail('STATE','Для поездки нужна действующая аренда.');
 if(state.ride)return{ok:true,state,duplicate:true};
 const s=clone(state);s.ride={id,routeId,progress:0,baseCharge:s.bike.charge,baseKm:s.bike.odometerKm,startedAt:now,paused:false};return commit(s);
}
export function advanceRide(state,progress,route,now=Date.now()){
 if(!state.ride)return{ok:true,state};
 if(state.status!=='active'||state.lease.endsAt<=now)return fail('STATE','Срок аренды закончился.');
 if(!route||route.id!==state.ride.routeId||!Number.isFinite(route.distanceMeters)||route.distanceMeters<=0)return fail('ROUTE','Маршрут недоступен.');
 const s=clone(state),ride=s.ride,p=Math.max(ride.progress,Math.min(1,Number(progress)||0));
 ride.progress=p;const spent=Math.min(ride.baseCharge,Math.max(1,Math.round(route.distanceMeters/850)));
 s.bike.charge=Math.max(0,Math.round((ride.baseCharge-spent*p)*10)/10);s.bike.odometerKm=Math.round((ride.baseKm+route.distanceMeters/1000*p)*100)/100;s.bike.lastSeenAt=now;
 if(p>=1){
  if(!s.trips.some(t=>t.id===ride.id))s.trips.unshift({id:ride.id,routeId:route.id,createdAt:now,distanceMeters:route.distanceMeters,durationSeconds:route.durationSeconds,chargeUsed:spent,startCharge:ride.baseCharge,endCharge:s.bike.charge});
  s.ride=null;s.notifications.unshift({id:uid(),title:'Поездка сохранена',text:'Маршрут и расход заряда появились в истории.',at:now});
 }
 return commit(s);
}
export function addTicket(state,{topic,text},now=Date.now()){
 if(!['service','renewal','other'].includes(topic)||typeof text!=='string'||text.trim().length<5||text.length>500)return fail('INPUT','Напиши от 5 до 500 символов.');
 const s=clone(state);s.tickets.unshift({id:'HELP-'+String(s.tickets.length+1).padStart(3,'0'),topic,text:text.trim(),createdAt:now,status:'Демообращение сохранено'});return commit(s);
}
export function seedState(scenario='active',model='u2',now=Date.now()){
 const format=scenario==='subscription'?'subscription':'rental';
 if(scenario==='new')return newRental({model},now);
 const remaining=scenario==='late'?DAY:scenario==='boundary'?48*HOUR:scenario==='expired'?-HOUR:5*DAY;
 const useDays=format==='subscription'?30:9,issued=now+remaining-useDays*DAY;
 let s=newRental({model,format,days:7,periods:1,firstCustomer:true},issued-HOUR);
 s=signContract(s,{code:'123456',accepted:true},issued-HOUR).state;s=initialPayment(s,'seed-payment',issued-HOUR).state;
 if(scenario==='pickup')return{...s,scenario};
 s=handover(s,'seed-handover',issued).state;s.scenario=scenario;s.bike.lastSeenAt=now;
 if(scenario==='low'){s.bike.charge=17;s.bike.spareCharge=63}
 if(scenario==='offline'){s.bike.connection=false;s.bike.lastSeenAt=now-3*HOUR}
 s.trips=[{id:'history-1',routeId:'petrograd-palace',createdAt:now-DAY,distanceMeters:7368,durationSeconds:1500,chargeUsed:9,startCharge:93,endCharge:84},{id:'history-2',routeId:'holland-sevkabel',createdAt:now-2*DAY,distanceMeters:5181,durationSeconds:1080,chargeUsed:6,startCharge:99,endCharge:93},{id:'history-3',routeId:'palace-smolny',createdAt:now-3*DAY,distanceMeters:5239,durationSeconds:1140,chargeUsed:6,startCharge:100,endCharge:94}];
 return s;
}
export function validState(s){
 if(!s||s.version!==STATE_VERSION||!['draft','awaiting_pickup','active','return_requested','completed'].includes(s.status))return false;
 if(!['u2','v8'].includes(s.selection?.model)||!['rental','subscription'].includes(s.selection?.format)||!s.initialQuote?.ok||!s.lease||!s.customer)return false;
 if(!['payments','documents','trips','renewals','notifications','tickets'].every(k=>Array.isArray(s[k]))||!s.operations||typeof s.operations!=='object')return false;
 if(!Number.isFinite(s.bike?.charge)||s.bike.charge<0||s.bike.charge>100||!Number.isFinite(s.bike?.spareCharge)||!Number.isFinite(s.bike?.odometerKm))return false;
 return ['draft','awaiting_pickup'].includes(s.status)||time(s.lease.endsAt);
}
