export const money=v=>new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:0}).format(v/100);
export const date=(v,time=true)=>v==null?'После выдачи':new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'long',year:'numeric',...(time?{hour:'2-digit',minute:'2-digit'}:{})}).format(new Date(v));
export const modelName=id=>id==='v8'?'V8 Max':'U2';
export const days=n=>n%10===1&&n%100!==11?'день':n%10>=2&&n%10<=4&&(n%100<12||n%100>14)?'дня':'дней';
export const number=v=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:1}).format(v);
export const offerLabel=status=>status==='proposal'?'Предлагаемый тариф подписки':'Пример по общему предложению';
export const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
