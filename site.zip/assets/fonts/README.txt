Manrope, variable weights 400-800, Google Fonts v20.
Cyrillic: https://fonts.gstatic.com/s/manrope/v20/xn7gYHE41ni1AdIRggOxSvfedN62Zw.woff2
Latin: https://fonts.gstatic.com/s/manrope/v20/xn7gYHE41ni1AdIRggexSvfedN4.woff2
Currency subset (Latin Extended, includes U+20BD): https://fonts.gstatic.com/s/manrope/v20/xn7gYHE41ni1AdIRggmxSvfedN62Zw.woff2
License: SIL Open Font License 1.1; see OFL.txt.
Retrieved 2026-09-24. Served locally; no runtime Google Fonts request.
