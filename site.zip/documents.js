
import {money,date,modelName,days,offerLabel} from './format.js';
export function documentSections(doc){
 const common={title:'Данные документа',lines:[`Номер: ${doc.id}`,`Создан: ${date(doc.createdAt)} МСК`,`Арендатор: ${doc.customer} (вымышленный клиент)`,`Модель: ${modelName(doc.model)}`,`Экземпляр: ${doc.vehicleId||'назначается при выдаче'}`]};
 const sections=[common];
 if(doc.type==='return')sections.push({title:'Возврат',lines:[`Байк принят сотрудником: ${date(doc.returnedAt)} МСК.`,`Плановое окончание аренды: ${date(doc.endsAt)} МСК.`,`Аренда завершена после приёмки. Это демонстрационный акт.`]});
 else{
  sections.push({title:doc.type==='renewal'?'Продление аренды':'Условия аренды',lines:[`Формат: ${doc.format==='subscription'?'подписка на 30 дней':'аренда по дням'}.`,`Оплачено: ${doc.paidDays} ${days(doc.paidDays)}.`,`Подарок: ${doc.bonusDays} ${days(doc.bonusDays)}. ${doc.type==='renewal'?'Правило раннего продления.':'Первоначальный бонус, если применим.'}`,`Сумма: ${money(doc.amount)}. Демооперация, деньги не списывались.`,`${offerLabel(doc.offerStatus)}. Версия каталога: ${doc.catalogVersion||'текущая'}.`]});
  sections.push({title:'Срок пользования',lines:doc.type==='contract'?['Срок начинается при выдаче байка сотрудником.','Точные даты и номер экземпляра фиксируются в акте выдачи.',`Общий первоначальный срок: ${doc.useDays} ${days(doc.useDays)}.`]:[`${doc.type==='renewal'?'Предыдущее окончание':'Начало аренды'}: ${date(doc.startsAt)} МСК.`,`Окончание: ${date(doc.endsAt)} МСК.`,...(doc.type==='renewal'?[`Подтверждение платежа: ${doc.paymentId}.`,'Остаток прежнего срока сохранён. Основной договор и выданный байк остаются прежними.']:['Комплект: 2 аккумулятора, зарядка, замок, багажник и держатель телефона.'])]});
 }
 if(doc.signatureAt)sections.push({title:'Демонстрационное подтверждение',lines:[`Демокод подтверждён: ${date(doc.signatureAt)} МСК.`,'Настоящая электронная подпись и SMS не подключены.']});
 sections.push({title:'Важно для демонстрации',lines:['Вымышленные данные. Документ не создаёт юридических обязательств.','Заявка на возврат сама не завершает аренду. Нужна приёмка сотрудником.','Подарочный день за продление: от 7 оплаченных дней, оплата за 48 часов или раньше; один подарок на операцию. Первоначальные +2 дня не повторяются. Все даты указаны по Москве.']});
 return sections;
}

