import {catalog} from './catalog.js';
export function dayWord(n){const a=Math.abs(n)%100,b=a%10;return a>=11&&a<=14?'дней':b===1?'день':b>=2&&b<=4?'дня':'дней'}
export function money(n){return new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',minimumFractionDigits:0,maximumFractionDigits:2}).format(n/100)}
export function calculateQuote(selection, config=catalog){
 const {bike,days,format='rental',firstCustomer=false}=selection;
 if(!Object.hasOwn(config.models,bike))return{status:'invalid',message:'Выбери велосипед.'};
 if(!['rental','subscription','buyout'].includes(format))return{status:'invalid',message:'Выбери формат аренды.'};
 if(typeof firstCustomer!=='boolean')return{status:'invalid',message:'Проверь условие первой аренды.'};
 if(!Number.isSafeInteger(days)||days<1||!Number.isSafeInteger(days+2))return{status:'invalid',message:'Укажи целое количество дней, от 1.'};
 const base={bike,format,days,firstCustomer,catalogVersion:config.version,modelConfirmed:false,total:null,deposit:null,dueAtPickup:null};
 if(format==='subscription'){
  const s=config.offers.subscription,periods=selection.subscriptionPeriods===undefined?1:selection.subscriptionPeriods;
  if(!Number.isSafeInteger(periods)||periods<1||periods>12)return{status:'invalid',message:'Выбери от 1 до 12 периодов подписки.'};
  const program=s.programs?.[bike];
  if(s.status!=='proposal'||!program||!Number.isSafeInteger(program.periodKopecks)||program.periodKopecks<1||s.periodDays!==30)return{...base,status:'terms_pending',subscriptionPeriods:periods,schedule:null};
  const total=periods*program.periodKopecks;if(!Number.isSafeInteger(total))return{status:'invalid',message:'Проверь стоимость подписки.'};
  return{...base,status:'proposal',scope:'proposed_program',version:s.version,total,subscriptionPeriods:periods,periodDays:s.periodDays,periodKopecks:program.periodKopecks,useDays:periods*s.periodDays,batteries:s.batteries,bonusDays:0,dueAtPickup:program.periodKopecks,schedule:{first:program.periodKopecks,count:periods-1,regular:program.periodKopecks,final:0,intervalDays:s.periodDays,totalPayments:periods}};
 }
 if(format==='buyout'){
  const offer=config.offers.buyout;
  if(offer.status==='proposal'){
   const b=offer.programs?.[bike];
   if(!b||[b.firstPaymentKopecks,b.regularPaymentKopecks,b.finalPaymentKopecks].some(n=>!Number.isSafeInteger(n)||n<0)||!Number.isSafeInteger(b.paymentCount)||b.paymentCount<1||b.intervalDays!==7||!b.ownershipCondition)return{...base,status:'schedule_pending',weeklyFrom:offer.weeklyFromKopecks,schedule:null};
   const total=b.firstPaymentKopecks+b.paymentCount*b.regularPaymentKopecks+b.finalPaymentKopecks;
   if(!Number.isSafeInteger(total))return{status:'invalid',message:'Проверь график платежей.'};
   return{...base,status:'proposal',scope:'proposed_program',total,version:offer.version,batteries:offer.batteries,bonusDays:0,dueAtPickup:b.firstPaymentKopecks,weeklyFrom:offer.weeklyFromKopecks,schedule:{first:b.firstPaymentKopecks,count:b.paymentCount,regular:b.regularPaymentKopecks,final:b.finalPaymentKopecks,intervalDays:b.intervalDays,totalPayments:b.paymentCount+1,ownershipCondition:b.ownershipCondition}};
  }
  const b=offer;
  if(b.status!=='confirmed'||!Array.isArray(b.modelIds)||!b.modelIds.includes(bike))return{...base,status:'schedule_pending',weeklyFrom:b.weeklyFromKopecks,schedule:null};
  const amounts=[b.firstPaymentKopecks,b.regularPaymentKopecks,b.finalPaymentKopecks];
  if(amounts.some(n=>!Number.isSafeInteger(n)||n<0)||!Number.isSafeInteger(b.paymentCount)||b.paymentCount<1||!b.ownershipCondition)return{...base,status:'schedule_pending',schedule:null};
  const total=b.firstPaymentKopecks+b.paymentCount*b.regularPaymentKopecks+b.finalPaymentKopecks;
  if(!Number.isSafeInteger(total))return{status:'invalid',message:'Проверь график платежей.'};
  const intervalDays=Number.isSafeInteger(b.intervalDays)&&b.intervalDays>0?b.intervalDays:b.periodicity==='weekly'?7:null;
  const totalPayments=b.paymentCount+Number(b.firstPaymentKopecks>0)+Number(b.finalPaymentKopecks>0);
  if(!Number.isSafeInteger(totalPayments))return{status:'invalid',message:'Проверь количество платежей.'};
  const batteries=Number.isSafeInteger(b.batteries)&&b.batteries>0?b.batteries:null;
  return{...base,status:'ready',modelConfirmed:true,scope:'model',total,version:b.version,batteries,bonusDays:0,schedule:{first:b.firstPaymentKopecks,count:b.paymentCount,regular:b.regularPaymentKopecks,final:b.finalPaymentKopecks,totalPayments,intervalDays,ownershipCondition:b.ownershipCondition}};
 }
 const offerId=config.models[bike].offerId;
 const offer=config.offers[offerId]||config.offers.general;
 if(Number.isInteger(offer.minDays)&&days<offer.minDays)return{status:'invalid',message:'Минимальный оплачиваемый срок — '+offer.minDays+' '+dayWord(offer.minDays)+'.'};
 if(!Number.isSafeInteger(offer.dailyKopecks)||offer.dailyKopecks<0)return{status:'invalid',message:'Тариф требует уточнения.'};
 const total=days*offer.dailyKopecks;
 if(!Number.isSafeInteger(total)||total<0)return{status:'invalid',message:'Этот срок нужно обсудить с командой.'};
 const assigned=Boolean(offerId&&config.offers[offerId]&&['confirmed','confirmed_general_offer'].includes(offer.status));
 const bonusDays=firstCustomer&&days>=offer.firstCustomerBonus.minimumPaidDays?offer.firstCustomerBonus.days:0;
 return{...base,status:assigned?'ready':'offer_example',scope:assigned?'model':'general_offer',modelConfirmed:assigned,offerId:offer.id,version:offer.version,total:assigned?total:null,exampleTotal:total,dailyKopecks:offer.dailyKopecks,bonusDays,useDays:days+bonusDays,batteries:offer.batteries,deposit:assigned?offer.depositKopecks:null,exampleDeposit:offer.depositKopecks,dueAtPickup:assigned?offer.paymentAtPickup:null};
}
