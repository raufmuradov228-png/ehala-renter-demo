// Scenario assumptions, not verified specifications of the rental fleet.
// Source details and limitations: project/specs/RANGE_V06.md.
export const rangeProfileVersion='range-preliminary-2026-09-24-v1';
export const rangeDefaults=Object.freeze({riderKg:80,cargoKg:0,speedKmh:25,batteryCount:1});
export const rangeInputLimits=Object.freeze({riderKg:[40,160],cargoKg:[0,40],speedKmh:[10,40]});
export const rangeProfiles=Object.freeze({
 u2:Object.freeze({modelId:'u2',name:'U2',nominalWh:2100,bikeWithOneBatteryKg:[70,73],spareBatteryKg:[8,16],status:'research_assumption'}),
 v8:Object.freeze({modelId:'v8',name:'V8 Max',nominalWh:1380,bikeWithOneBatteryKg:[50,55],spareBatteryKg:[6,12],status:'research_assumption'})
});
const constants=Object.freeze({gravity:9.81,airDensity:1.20,stopsPerKm:2,reserveFraction:.10});
const lossScenarios=Object.freeze({
 low:Object.freeze({crr:.008,cda:.50,efficiency:.80,usableFraction:.90,auxiliaryWatts:10,massIndex:0}),
 high:Object.freeze({crr:.012,cda:.80,efficiency:.55,usableFraction:.75,auxiliaryWatts:25,massIndex:1})
});
const conditions='Сухой ровный асфальт, +20 °C, без ветра, педалирования и рекуперации. Две полные остановки на километр; 10% энергии оставлено в резерве. Диапазон показывает чувствительность к допущениям, а не гарантированный пробег.';
function scenario(profile,input,loss){
 const {riderKg,cargoKg,speedKmh,batteryCount}=input;
 // The installed battery is already in the bicycle mass. Both batteries stay
 // on the bicycle for the entire two-battery trip, including the empty one.
 const totalMassKg=profile.bikeWithOneBatteryKg[loss.massIndex]+riderKg+cargoKg+(batteryCount-1)*profile.spareBatteryKg[loss.massIndex];
 const velocity=speedKmh/3.6;
 const rollingForce=loss.crr*totalMassKg*constants.gravity;
 const aerodynamicForce=.5*constants.airDensity*loss.cda*velocity**2;
 const rollingAndAirWhPerKm=(rollingForce+aerodynamicForce)/(3.6*loss.efficiency);
 const accelerationWhPerKm=constants.stopsPerKm*totalMassKg*velocity**2/(7200*loss.efficiency);
 const auxiliaryWhPerKm=loss.auxiliaryWatts/speedKmh;
 const whPerKm=rollingAndAirWhPerKm+accelerationWhPerKm+auxiliaryWhPerKm;
 const usableWh=batteryCount*profile.nominalWh*loss.usableFraction*(1-constants.reserveFraction);
 return {totalMassKg,whPerKm,usableWh,rangeKm:usableWh/whPerKm};
}
export function estimateRange({modelId,riderKg=80,cargoKg=0,speedKmh=25,batteryCount=1}={}){
 const inputs={riderKg,cargoKg,speedKmh,batteryCount};
 const common={modelId,batteryCount,inputs,profileVersion:rangeProfileVersion,conditions,lowerKm:null,upperKm:null,displayLowerKm:null,displayUpperKm:null};
 if(!Object.hasOwn(rangeProfiles,modelId))return {...common,status:'unavailable',message:'Для этой модели предварительный расчёт ещё не подготовлен.'};
 for(const [key,[minimum,maximum]] of Object.entries(rangeInputLimits)){
  if(typeof inputs[key]!=='number'||!Number.isFinite(inputs[key])||inputs[key]<minimum||inputs[key]>maximum){
   const labels={riderKg:'Вес человека — от 40 до 160 кг.',cargoKg:'Вес груза — от 0 до 40 кг.',speedKmh:'Скорость расчёта — от 10 до 40 км/ч.'};
   return {...common,status:'invalid',field:key,message:labels[key]};
  }
 }
 if(![1,2].includes(batteryCount))return {...common,status:'invalid',field:'batteryCount',message:'Выбери один или два аккумулятора.'};
 const profile=rangeProfiles[modelId],highLoss=scenario(profile,inputs,lossScenarios.high),lowLoss=scenario(profile,inputs,lossScenarios.low);
 return {...common,status:'estimated',lowerKm:highLoss.rangeKm,upperKm:lowLoss.rangeKm,displayLowerKm:Math.floor(highLoss.rangeKm),displayUpperKm:Math.floor(lowLoss.rangeKm),scenarios:{highLoss,lowLoss},message:'Предварительная оценка по исследовательским параметрам. Фактический пробег комплектации пока не измерен.'};
}
export function assessTrip({outboundKm,returnKm,returnToStart}={},estimate){
 if(typeof returnToStart!=='boolean'||!Number.isFinite(outboundKm)||outboundKm<0||(returnToStart&&(!Number.isFinite(returnKm)||returnKm<0)))return {status:'distance_required',totalKm:null,message:'Построй маршрут или введи расстояния туда и обратно.'};
 const totalKm=outboundKm+(returnToStart?returnKm:0);
 if(!Number.isFinite(totalKm)||totalKm<=0)return {status:'distance_required',totalKm:null,message:'Построй маршрут или введи известное расстояние.'};
 if(estimate?.status!=='estimated'||!Number.isFinite(estimate.lowerKm)||!Number.isFinite(estimate.upperKm)||estimate.lowerKm<=0||estimate.upperKm<estimate.lowerKm)return {status:'estimate_unavailable',totalKm,message:'Расстояние известно. Проверь параметры предварительной оценки.'};
 const common={totalKm,remainingLowerKm:Math.max(0,estimate.lowerKm-totalKm),remainingUpperKm:Math.max(0,estimate.upperKm-totalKm),profileVersion:estimate.profileVersion,conditions:estimate.conditions};
 if(totalKm<=estimate.lowerKm)return {...common,status:'within_lower_estimate',message:'Поездка укладывается в нижнюю границу предварительной оценки. Реальный запас может отличаться.'};
 if(totalKm<=estimate.upperKm)return {...common,status:'within_estimate_spread',message:'Поездка между границами оценки: при больших потерях запаса может не хватить.'};
 return {...common,status:'exceeds_estimate',excessKm:totalKm-estimate.upperKm,message:'Поездка длиннее верхней границы предварительной оценки.'};
}
export function areaBudget(estimate){
 if(estimate?.status!=='estimated'||!Number.isFinite(estimate.lowerKm)||estimate.lowerKm<=0)return {budgetKm:null,capped:false,reason:'estimate_unavailable'};
 const rounded=Math.floor(estimate.lowerKm/5)*5;
 if(rounded<10)return {budgetKm:null,capped:false,reason:'below_minimum'};
 return {budgetKm:Math.min(100,rounded),capped:estimate.lowerKm>100,reason:null};
}
