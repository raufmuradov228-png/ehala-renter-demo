// Owner's general offer is deliberately not assigned to either fleet model.
export const catalog = {
  version: '2026-09-25-v07-included-accessories',
  includedAccessories:{status:'confirmed',models:['u2','v8'],source:'Owner confirmed all four items without surcharge for both models, 2026-09-25',items:[
    {id:'charger',name:'Зарядное устройство',image:'/assets/v07/kit-charger.webp'},
    {id:'rack',name:'Курьерский багажник',image:'/assets/v07/kit-rack.webp'},
    {id:'phone-holder',name:'Держатель телефона',image:'/assets/v07/kit-phone-holder.webp'},
    {id:'lock',name:'Замок',image:'/assets/v07/kit-lock.webp'}
  ]},
  models: {
    v8: {id:'v8', legacyId:'bike-a-60-23',name:'V8 MAX', subtitle:'Открытая рама · отдельное седло', batteryLabel:'60/23', offerId:null, range:null, routing:null},
    u2: {id:'u2', legacyId:'bike-b-u2-60-35',name:'U2', subtitle:'Длинное седло · площадка для ног', batteryLabel:'60/35', offerId:null, range:null, routing:null}
  },
  offers: {
    general: {id:'general',status:'confirmed_general_offer',version:'owner-2026-09-23',currency:'RUB',dailyKopecks:55000,depositKopecks:0,batteries:2,minDays:1,firstCustomerBonus:{minimumPaidDays:7,days:2},paymentAtPickup:null,source:'Owner supplied offer and follow-up answers, 2026-09-23'},
    subscription:{id:'subscription',status:'proposal',version:'author-proposal-2026-09-24-v1',periodDays:30,minimumPeriods:1,maximumPeriods:12,batteries:2,source:'Author-designed programme; owner requested «придумай сам». Not an approved operating tariff.',programs:{
      u2:{periodKopecks:1490000},v8:{periodKopecks:1290000}
    }},
    buyout:{id:'buyout',status:'proposal',version:'author-proposal-2026-09-24-v1',weeklyFromKopecks:450000,batteries:2,source:'Author-designed programme; owner requested «придумай сам». Not an approved operating tariff.',programs:{
      u2:{firstPaymentKopecks:450000,paymentCount:39,regularPaymentKopecks:450000,finalPaymentKopecks:0,intervalDays:7,ownershipCondition:'После всех 40 платежей и выполнения условий согласованного договора.'},
      v8:{firstPaymentKopecks:450000,paymentCount:31,regularPaymentKopecks:450000,finalPaymentKopecks:0,intervalDays:7,ownershipCondition:'После всех 32 платежей и выполнения условий согласованного договора.'}
    }}
  },
  ownerClaims:{rangeKmPerBatteryMaximum:80,speedKmhMaximum:70,loadKgMaximum:200,equipment:['keyless_access','alarm','phone_holder_charging','optional_speed_limiter'],status:'not_mapped_to_models',source:'Owner supplied advertisement'},
  contacts:{avito:'https://www.avito.ru/brands/1417ba1edcc8d9c610ecf445abdf7386/all/predlozheniya_uslug'}
};
export const formatLabels = {rental:'Аренда',subscription:'Подписка',buyout:'Аренда с выкупом'};
export const features = {
  battery:{name:'Аккумулятор',title:'Продумай зарядку заранее.',text:'Рассмотри расположение батареи. В общем предложении — два аккумулятора: комплект выбранной модели подтвердим перед выдачей.',note:'Способ замены, зарядку и пробег уточняем по комплектации.',target:'battery'},
  seat:{name:'Посадка',title:'Найди свой способ ехать.',text:'У V8 Max — отдельное седло и открытая рама. У U2 — длинное седло и площадка для ног. Сравни компоновку и положение руля.',note:'Удобство зависит от роста. Регулировки и примерку согласуем перед арендой.',target:'seat'},
  rack:{name:'Багажник',title:'Место для твоих вещей.',text:'Курьерский багажник включён без доплаты для U2 и V8 Max. Посмотри, как он расположен на велосипеде.',note:'Размеры, допустимая нагрузка и крепление конкретной термосумки требуют проверки.',target:'rack'},
  suspension:{name:'Ходовая',title:'Рассмотри технику ближе.',text:'Приблизь колёса, вилку и элементы подвески. На модели можно рассмотреть их расположение с разных сторон.',note:'Тип тормозов и условия обслуживания подтверждаем для конкретного велосипеда.',target:'suspension'},
  phone:{name:'Телефон',title:'Навигация под рукой.',text:'Держатель телефона включён без доплаты для обеих моделей. Настройку покажем при получении.',note:'Разъём питания и точное место установки проверяем на выдаваемом велосипеде.',target:null},
  access:{name:'Доступ',title:'Детали ежедневного пользования.',text:'В предложении заявлены бесключевой доступ и сигнализация. Покажем, как они работают на выдаваемом велосипеде.',note:'Наличие и работу системы подтверждаем при выдаче. Сигнализация не гарантирует защиту от угона.',target:null}
};
