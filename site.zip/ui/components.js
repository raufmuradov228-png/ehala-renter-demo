
import {icon} from './icons.js';
import {escape as esc, date, money, days, modelName} from '../format.js';
export {icon};
export const shortDate=(v,time=false)=>new Intl.DateTimeFormat('ru-RU',{timeZone:'Europe/Moscow',day:'numeric',month:'long',...(new Date(v).getUTCFullYear()!==new Date().getUTCFullYear()?{year:'numeric'}:{}),...(time?{hour:'2-digit',minute:'2-digit'}:{})}).format(new Date(v));
export const button=(label,action,style='primary',attrs='')=>`<button type="button" class="button ${style}" data-action="${action}" ${attrs}>${label}${style==='primary'?icon('arrow'):''}</button>`;
export const pageTitle=(title,back='')=>`<div class="page-title">${back?`<button class="icon-button back" data-action="${back}" aria-label="Назад">${icon('arrow')}</button>`:''}<h1>${title}</h1></div>`;
export const sectionTitle=(title,action='',label='Все')=>`<div class="section-title"><h2>${title}</h2>${action?`<button class="text-link" data-action="${action}">${label}</button>`:''}</div>`;
export const menuRow=(symbol,title,detail,action,attrs='')=>`<button class="menu-row" data-action="${action}" ${attrs}><span class="menu-icon">${icon(symbol)}</span><span class="grow"><b>${title}</b>${detail?`<small>${detail}</small>`:''}</span><span class="chevron">${icon('arrow')}</span></button>`;
export const errorMessage=message=>`<p class="form-error" role="alert">${esc(message||'')}</p>`;
export const modelImage=(model,className='')=>`<img class="bike-image ${className}" src="./assets/${model}.webp" alt="Электробайк ${modelName(model)}, вид целиком" width="700" height="480">`;
export function quoteRows(q,renewal=false){
 return `<dl class="quote-rows"><div><dt>Оплаченный срок</dt><dd>${q.paidDays} ${days(q.paidDays)}</dd></div>
 <div class="${q.bonusDays?'bonus-row':''}"><dt>${renewal?'Подарочный день':'Подарок за первую аренду'}</dt><dd>${q.bonusDays?`+${q.bonusDays} ${days(q.bonusDays)}`:'Без подарка'}</dd></div>
 ${renewal?`<div><dt>Сейчас до</dt><dd>${date(q.oldEndsAt)} МСК</dd></div><div class="new-end"><dt>После продления</dt><dd>${date(q.endsAt)} МСК</dd></div>`:`<div><dt>Всего с байком</dt><dd>${q.useDays} ${days(q.useDays)}</dd></div>`}</dl>`;
}
export function routeShape(route){
 if(!route?.coordinates?.length)return '';
 const c=Math.cos(route.coordinates[0][1]*Math.PI/180);
 const pts=route.coordinates.map(([x,y])=>[x*c,-y]);
 const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),lx=Math.min(...xs),hx=Math.max(...xs),ly=Math.min(...ys),hy=Math.max(...ys),scale=Math.min(90/(hx-lx||1),48/(hy-ly||1));
 const points=pts.map(([x,y])=>`${(60+(x-(lx+hx)/2)*scale).toFixed(1)},${(36+(y-(ly+hy)/2)*scale).toFixed(1)}`).join(' ');
 return `<svg viewBox="0 0 120 72" aria-hidden="true"><polyline points="${points}" fill="none" stroke="#202421" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/><polyline points="${points}" fill="none" stroke="#c5fa36" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}
export function tripRow(trip,route){
 return `<button class="trip-row" data-action="trip" data-id="${esc(trip.id)}"><span class="route-thumbnail">${routeShape(route)}</span><span class="grow"><small>${shortDate(trip.createdAt)}</small><b>${esc(route?.label||'Поездка по Петербургу')}</b><span>${(trip.distanceMeters/1000).toFixed(1).replace('.',',')} км <i>·</i> ${Math.round(trip.durationSeconds/60)} мин</span></span><span class="trip-charge">−${trip.chargeUsed}%</span></button>`;
}
export const mapHTML=(route,ride=false)=>route?`<div class="map-wrap" data-live="${ride}" data-route="${route.id}"><img class="map-fallback" src="./assets/${route.fallbackSvg}" alt="Схема маршрута: ${esc(route.startName)} — ${esc(route.endName)}"><div id="live-map" class="live-map" aria-label="Карта собственного байка"></div><div class="map-badge"><span id="map-mode">Схема маршрута · офлайн</span></div>${ride?'<svg class="fallback-progress" viewBox="0 0 640 430" aria-hidden="true"><circle id="fallback-marker" cx="320" cy="218" r="9" fill="#172b13" stroke="#c5fa36" stroke-width="4"/></svg>':''}</div>`:'<div class="map-empty">Маршрут пока недоступен<button class="text-link" data-action="reload-routes">Повторить загрузку</button></div>';

