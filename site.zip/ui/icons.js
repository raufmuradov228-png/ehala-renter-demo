const paths={
rent:'<path d="m3 10 9-7 9 7v10H3Z"/><path d="M9 20v-7h6v7"/>',
bike:'<circle cx="5" cy="17" r="4"/><circle cx="19" cy="17" r="4"/><path d="m5 17 5-9 5 9H5m3-12h4m3 12-3-9h6l1 4"/>',
trips:'<circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 5h9a4 4 0 0 1 0 8H8a3 3 0 0 0 0 6h9"/>',
documents:'<path d="M6 2h9l4 4v16H6Z"/><path d="M14 2v5h5M9 12h7m-7 4h7"/>',
profile:'<circle cx="12" cy="8" r="4"/><path d="M4 22v-2a8 8 0 0 1 16 0v2"/>',
arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
gift:'<path d="M3 9h18v4H3zm2 4v8h14v-8M12 9v12"/><path d="M12 9C2 9 5-1 12 9Zm0 0C22 9 19-1 12 9Z"/>',
battery:'<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M6 10v4m4-4v4m4-4v4"/>',
check:'<path d="m5 12 4 4L19 6"/>',
download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
bell:'<path d="M18 8a6 6 0 0 0-12 0c0 8-2 8-2 9h16c0-1-2-1-2-9M10 21h4"/>',
pin:'<path d="M19 9c0 6-7 12-7 12S5 15 5 9a7 7 0 0 1 14 0Z"/><circle cx="12" cy="9" r="2"/>',
close:'<path d="m6 6 12 12M6 18 18 6"/>',
play:'<path d="m8 4 13 8-13 8Z"/>',
wifi:'<path d="M2 8a16 16 0 0 1 20 0M5 12a11 11 0 0 1 14 0M8 16a6 6 0 0 1 8 0M12 20h.01"/>'
};
export function icon(name){return `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.arrow}</svg>`}
