export function normalizeRoute(hash=''){
 const parts=hash.replace(/^#\/?/,'').split('/');let section=parts[0]||'home';
 if(['rent','bike'].includes(section))section='home';
 if(section==='profile'&&['documents','payments'].includes(parts[1]))section=parts[1];
 if(section==='home'&&['location','return-status'].includes(parts[1]))section=parts[1];
 if(section==='trips'&&parts[1])return{screen:'trip',tab:'trips',id:decodeURIComponent(parts[1]),hash:'#/trips/'+parts[1]};
 if(!['home','trips','profile','documents','payments','location','return-status'].includes(section))section='home';
 return{screen:section,tab:['documents','payments'].includes(section)?'profile':['location','return-status'].includes(section)?'home':section,hash:'#/'+(['documents','payments'].includes(section)?'profile/':['location','return-status'].includes(section)?'home/':'')+section};
}
